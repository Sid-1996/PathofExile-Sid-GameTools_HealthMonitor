# Path of Exile Sid遊戲工具 - 混淆源代碼版本

## ⚠️ 重要說明

這是 **Path of Exile Sid遊戲工具** 的混淆源代碼版本，僅供學習和技術研究使用。

### 混淆內容
- 主要類名和函數名已進行替換
- 保留了完整的代碼邏輯和功能
- 適合學習Python GUI開發、圖像處理、鍵盤監聽等技術

### 使用方式
1. 確保已安裝所有依賴包：
   ```
   pip install tkinter opencv-python numpy keyboard pygetwindow pillow pyautogui
   ```

2. 運行混淆版本：
   ```bash
   python health_monitor_obfuscated.py
   ```

### 原始功能
- 血量/魔力監控
- 一鍵清包功能
- 自動拾取物品
- 技能連段執行
- 自動連點
- 全局熱鍵控制

### 技術特點
- 使用OpenCV進行圖像處理
- Tkinter GUI界面
- 全局鍵盤監聽
- 窗口管理
- 配置檔案持久化

### 學習價值
此混淆版本適合學習：
- Python大型項目架構
- GUI應用開發
- 圖像識別技術
- 系統級編程
- 遊戲輔助工具開發

**注意：** 此版本不可直接用於商業用途，僅供技術學習參考。

---
*Path of Exile Sid遊戲工具 v1.0.3 - 混淆學習版本*